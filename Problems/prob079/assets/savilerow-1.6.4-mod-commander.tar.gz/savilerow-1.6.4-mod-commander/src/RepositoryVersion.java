package savilerow;
public final class RepositoryVersion {
    public static String repositoryVersion = "5438fd59987a (2017-03-06 21:15 +0000)";
}
